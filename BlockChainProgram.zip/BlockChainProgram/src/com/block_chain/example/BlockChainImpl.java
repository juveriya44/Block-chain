package com.block_chain.example;
import java.util.ArrayList;
import java.util.List;

public class BlockChainImpl {
	
	private List<BlockChainStructure> blockChainList = new ArrayList<>();

	public List<BlockChainStructure> getBlockChainList() {
		return blockChainList;
	}
	
	private BlockChainStructure getPreviousBlockChain() {
		if (blockChainList.isEmpty()) {
			createGenesisBlock();
		}
		return blockChainList.get(blockChainList.size() - 1);
	}
	
	private void createGenesisBlock() {
		blockChainList.add(new BlockChainStructure(0, 1250, 1, "", "", ""));
	}
	
	public void addBlockChain(int data, int difficulty, String sender, String recipient) {
		BlockChainStructure prevBlockChain = getPreviousBlockChain();
		BlockChainStructure newBlockChain = new BlockChainStructure(prevBlockChain.getIndex() + 1, data, difficulty, prevBlockChain.generateHash(), 
				  sender, recipient);
		blockChainList.add(newBlockChain);
	}
	
	public boolean isValidBlockChain() {
		for (int i = 1; i<blockChainList.size(); i++) {
			BlockChainStructure currentBlockChain = blockChainList.get(i);
			BlockChainStructure prevBlockChain = blockChainList.get(i-1);
			if (!prevBlockChain.generateHash().equals(currentBlockChain.getPreviousHash())) {
				return false;
			}
		}
		return true;
	}
	
	public String updateBlockChain(int index, int data, String sender, String recipient) {
		BlockChainStructure findBlockChain = getBlockChainList().get(index);
		if (findBlockChain != null) {
			if (data != 0) {
				getBlockChainList().get(index).setData(data);
			}
			if (sender != null) {
				getBlockChainList().get(index).setSender(sender);
			}
			if (recipient != null) {
				getBlockChainList().get(index).setRecipient(recipient);
			}
			return "Block Corrupted";
		} else {
			return "No Block Found";
		}
	}
	
	public void fixCorruption() {
		BlockChainStructure currentBlockChain, prevBlockChain;
		 
		//System.out.println(blockChainList.size());
		for (int i = 1; i<blockChainList.size(); i++) {
			currentBlockChain = blockChainList.get(i);
			prevBlockChain = blockChainList.get(i-1);
			String prevHash = prevBlockChain.generateHash();
			if(!prevHash.equals(currentBlockChain.getPreviousHash())) {
				currentBlockChain.setPreviousHash(prevHash);
			}			
		}
	}

	@Override
	public String toString() {
		return "BlockChainImpl [blockChainList=" + blockChainList + "] \n";
	}
	
	
}
