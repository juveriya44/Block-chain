package com.block_chain.example;
import java.lang.*;
import java.util.Scanner;

import java.util.*;
import com.google.gson.GsonBuilder;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;

import org.bson.Document;
import java.util.Arrays;
import com.mongodb.Block;

public class BlockChainMain {

	
	public static void main(String[] args) {
		BlockChainImpl blockChainImpl = new BlockChainImpl();
		String dbstring = "mongodb+srv://Juveriya:Juveriya@cluster1-1orym.mongodb.net/test?retryWrites=true&w=majority";

		MongoClientURI uri = new MongoClientURI(dbstring);

		MongoClient mongoClient = new MongoClient(uri);
		MongoDatabase database = mongoClient.getDatabase("blockChain");
        blockChainImpl.addBlockChain(1234 ,4 , "SenderName", "ReceiverName");
		System.out.println(blockChainImpl.getBlockChainList().toString());
		
		System.out.println(blockChainImpl.getBlockChainList().toString());
		System.out.println(blockChainImpl.isValidBlockChain());
		blockChainImpl.fixCorruption();
		System.out.println(blockChainImpl.getBlockChainList().toString());
		blockChainImpl.addBlockChain(1111 ,1 , "SenderName", "ReceiverName");
		System.out.println(blockChainImpl.getBlockChainList().toString());
		String strJSON = new GsonBuilder().setPrettyPrinting().create().toJson(blockChainImpl);
		System.out.println(strJSON);
	
		
	System.out.println("1.adding transaction prompt user forall the fields:\n"
			+ "2.verify block chain look for corruption:\n"
			+ "3.view blockchain print out each in json.tostring:\n"
			+ "4.corrupt a block:\n"
			+ "5.fix corruption by recomputing hash:\n"
			+ "6.Find the respected sender or receiver\n"
			+ "7.particular output with the input amount:\n"
			+ "8.particular row with amount less than input amount:\n"
			+"9.particular row with amount Greater than input amount:\n"
			+"10.Exit");
	
	MongoCollection<Document> collection = database.getCollection("blockChain");
	System.out.println(collection);
     boolean run =true;
     Scanner input= new Scanner(System.in) ;
     while(run==true)
     {
    	 System.out.println("enter the input you desire");
    	 
    	  
         String var = input.nextLine();
	switch(var)
	{
	case "1": 
		System.out.println("Enter the transaction data:\n");
		
		System.out.println("Enter sender:\n");
		String sender =input.nextLine();
		System.out.println("Enter Reciever:\n");
		String Receiver =input.nextLine();
		System.out.println("Enter data:\n");
		int Data =input.nextInt();
		System.out.println("Enter Difficulty Level:\n");
		int DLevel =input.nextInt();
		input.nextLine();
		
		
		blockChainImpl.addBlockChain(Data,DLevel ,sender,Receiver);
		System.out.println(blockChainImpl.getBlockChainList().toString());
		Document doc = new Document("Sender",sender)
	               .append("Reciever",Receiver)
	               .append("Data", Data)
	               .append("D-Level", DLevel)
	               .append("List",blockChainImpl.getBlockChainList().toString() );

	collection.insertOne(doc);
	
		
			break;
	case "2": 
		System.out.println(blockChainImpl.isValidBlockChain());
	break;
	case "3": // write the code 
		String strJSONs = new GsonBuilder().setPrettyPrinting().create().toJson(blockChainImpl);
		System.out.println(strJSONs);
		break;
	case "4": // write the code 
		System.out.println("Enter which block you would like to update:\n");
		int bno  =input.nextInt();
		input.nextLine();
		System.out.println("Enter Sender:\n");
		String Sender2 =input.nextLine();
		System.out.println("Enter Reciever:\n");
		String Receiver2 =input.nextLine();
		System.out.println("Enter data:\n");
		int Data2 =input.nextInt();
		
		 System.out.println(blockChainImpl.updateBlockChain(bno, Data2, Sender2, Receiver2));
		 System.out.println(blockChainImpl.isValidBlockChain());
		break;
	case "5": 
		System.out.println("fixing the corrupted block\n");
		
		blockChainImpl.fixCorruption();
       
		break;
	
	case "6":
		Scanner sc2 = new Scanner(System.in);
		System.out.println("Enter Sender or Recipient");
		String sen = sc2.next();
		System.out.println("Enter Name");
		String rec = sc2.next();
		
		
		FindIterable<Document> iterDoc = collection.find(Filters.eq(sen, rec));
		MongoCursor<Document> dbc = iterDoc.iterator();
		 try {
	            while(dbc.hasNext()) {
	                //log.info(cursor.next().toJson());
	            	System.out.println(dbc.next());
	            }
	        } finally {
	            dbc.close();
	        }
		 break;
	case "7":
		Scanner sc3 = new Scanner(System.in);
		System.out.println("Enter Amount");
		int amt=sc3.nextInt();
		
		FindIterable<Document> iterDoc1 = collection.find(Filters.eq("Data",amt));
		MongoCursor<Document> dbc1 = iterDoc1.iterator();
		 try {
	            while(dbc1.hasNext()) {
	                //log.info(cursor.next().toJson());
	            	System.out.println(dbc1.next());
	            }
	        } finally {
	            dbc1.close();
	        }
		break;
	case "8":
		Scanner sc4 = new Scanner(System.in);
		System.out.println("Enter Amount");
		int amt1=sc4.nextInt();
		
		FindIterable<Document> iterDoc2 = collection.find(Filters.lte("Data", amt1));
		MongoCursor<Document> dbc2 = iterDoc2.iterator();
		 try {
	            while(dbc2.hasNext()) {
	                //log.info(cursor.next().toJson());
	            	System.out.println(dbc2.next());
	            }
	        } finally {
	            dbc2.close();
	        }
		break;
	case "9":
		Scanner sc5 = new Scanner(System.in);
		System.out.println("Enter Amount");
		int amt3=sc5.nextInt();
		
		FindIterable<Document> iterDoc3 = collection.find(Filters.gte("Data", amt3));
		MongoCursor<Document> dbc3 = iterDoc3.iterator();
		 try {
	            while(dbc3.hasNext()) {
	                //log.info(cursor.next().toJson());
	            	System.out.println(dbc3.next());
	            }
	        } finally {
	            dbc3.close();
	        }
		break;
	case "10":
		run =false;
		mongoClient.close();
		System.exit(0); 
	break;
	default :
		System.out.println("Invalid input!!");
		break;

	}
	
     }
	
	}

}
