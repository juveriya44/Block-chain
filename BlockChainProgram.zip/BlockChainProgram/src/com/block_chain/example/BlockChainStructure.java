package com.block_chain.example;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class BlockChainStructure {
	
	private int index;
	private Timestamp timestamp;
	private int data;
	private int difficulty;
	private String previousHash;
	private BigInteger nonce;
	private String sender;
	private String recipient;

	
	BlockChainStructure(int index, int string, int difficulty, String previousHash, 
			String sender, String recipient) {
		this.index = index;
		this.timestamp = getTime();
		this.data = string;
		this.difficulty = difficulty;
		this.previousHash = previousHash;
		this.nonce = BigInteger.ONE;
		this.sender = sender;
		this.recipient = recipient;

	}
	

	public static Timestamp getTime() {
		return new Timestamp(System.currentTimeMillis());
	}
	
	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public Timestamp getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Timestamp timestamp) {
		this.timestamp = timestamp;
	}

	public int getData() {
		return data;
	}

	public void setData(int data) {
		this.data = data;
	}

	public int getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(int difficulty) {
		this.difficulty = difficulty;
	}

	public String getPreviousHash() {
		return previousHash;
	}

	public void setPreviousHash(String previousHash) {
		this.previousHash = previousHash;
	}

	public BigInteger getNonce() {
		return nonce;
	}

	public void setNonce(BigInteger nonce) {
		this.nonce = nonce;
	}

	public String getSender() {
		return sender;
	}

	public void setSender(String sender) {
		this.sender = sender;
	}

	public String getRecipient() {
		return recipient;
	}

	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}

	public String generateHash() {
		
		
		String leadingString =  new String(new char[this.difficulty]).replace('\0', '0');
		
		MessageDigest messageDigest = null;
		try {
			messageDigest = MessageDigest.getInstance("SHA-256");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		//System.out.println(inputString);
		String hashString = "";
		while(true)  {
			String inputString = String.valueOf(this.index + String.valueOf(this.timestamp) + this.data + 
					this.previousHash + this.nonce.toString() + this.sender + this.recipient);
			final byte inputBytes[] = messageDigest.digest(inputString.getBytes());
			final StringBuilder outputString = new StringBuilder();
			
			for(final byte temp : inputBytes) {
				String convertString = Integer.toHexString(0xff &temp);
				if(convertString.length() == 1) {
					outputString.append('0');
				}
				outputString.append(convertString);
			}
			//System.out.println(outputString.toString());
			hashString = outputString.toString();
			if(!hashString.substring(0, this.difficulty).equals(leadingString))
			{
				this.nonce = this.nonce.add(BigInteger.ONE);
				continue;
			}
			else
			{
				break;
			}
		}
		return hashString;
	}


	@Override
	public String toString() {
		return "BlockChainStructure [index=" + index + ", data=" + data + ", difficulty=" + difficulty
				+ ", previousHash=" + previousHash + ", nonce=" + nonce + ", sender=" + sender + ", recipient="
				+ recipient + "]";
	}
	
	
}
